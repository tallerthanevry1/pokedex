const express = require("express");
const PokemonRouter = require("./controllers/pokemon");
const methodOverride = require("method-override");
const morgan = require("morgan")
require("dotenv").config()

const PORT = process.env.PORT

app = express();

//middleware

app.use(methodOverride("_method"));
app.use("/static", express.static("public"));
app.use(morgan("tiny"))
app.use(express.urlencoded({extended: true})) // parse HTML form data 
app.use("/pokemon", PokemonRouter)

//test server

app.get("/", (req, res) => {
    res.send("Pokemon Server is functional and running")
})

// App listener
app.listen(PORT, (req, res) => {
    console.log(`Listening on port: ${PORT}`);
})
